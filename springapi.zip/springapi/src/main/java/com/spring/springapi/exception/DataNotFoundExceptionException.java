package com.spring.springapi.exception;

public class DataNotFoundExceptionException extends RuntimeException{

    public DataNotFoundExceptionException(String message) {
        super(message);
    }

}
